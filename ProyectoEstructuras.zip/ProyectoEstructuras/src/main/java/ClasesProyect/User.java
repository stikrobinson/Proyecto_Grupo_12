package ClasesProyect;

import Estructuras.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author alexo
 */
public class User {
    private String usuario;
    private String contrasena;
    private String nombre;
    private ArrayList<String> telefonos;
    //private ArrayList<Vehiculo> vehiculos;
    
    public User(String u, String p, String n, ArrayList<String> t){
        usuario = u; contrasena = p; nombre = n; telefonos = t; //vehiculos = new ArrayList<>();
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getUsuario(){
        return usuario;
    }
    
    public String getContrasena(){
        return contrasena;
    }
    /*
    public ArrayList<Vehiculo> getVehiculos(){
        return vehiculos;
    }*/
    
    public ArrayList<String> getTelefonos(){
        return telefonos;
    }
    
    public boolean equals(Object o){
        User u = (User) o;
        return u.getUsuario().equals(usuario);
    }
    
    @Override
    public String toString(){
        return nombre;
    }
}
