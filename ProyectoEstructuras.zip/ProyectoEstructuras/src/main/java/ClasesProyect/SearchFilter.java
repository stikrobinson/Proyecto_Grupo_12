/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ClasesProyect;

/**
 *
 * @author alexo
 */
public interface SearchFilter<E> {  //Implementacion de filtros

//    public TDAList<E> ordenarPorKilometraje();
//    public TDAList <E> filtrarPorMarcaModelo(String marca, String modelo);
//    public TDAList<E> filtrarPorRangoPrecio(double min, double max);
//    public TDAList<E> filtrarPorRangoKilometraje(int min, int max);
}
